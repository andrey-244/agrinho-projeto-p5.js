let player;
let obstacles = [];
let gravity = 0.2;
let score = 0;

function setup() {
  createCanvas(400, 600);
  player = new Player();
  frameRate(60);
}

function draw() {
  background(220);

  // Atualiza e desenha o jogador
  player.update();
  player.show();

  // Geração de obstáculos
  if (frameCount % 60 == 0) {
    obstacles.push(new Obstacle());
    score++;  // Aumenta o score com o tempo
  }

  // Atualiza e desenha os obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    // Checa se o jogador colidiu com algum obstáculo
    if (obstacles[i].hits(player)) {
      noLoop();  // Pausa o jogo
      textSize(32);
      fill(255, 0, 0);
      textAlign(CENTER, CENTER);
      text("GAME OVER", width / 2, height / 2);
      textSize(16);
      text("Score: " + score, width / 2, height / 2 + 40);
    }

    // Remove obstáculos que saíram da tela
    if (obstacles[i].offscreen()) {
      obstacles.splice(i, 1);
    }
  }

  // Exibe o score
  textSize(24);
  fill(0);
  text("Score: " + score, 10, 30);
}

function keyPressed() {
  if (keyCode === UP_ARROW) {
    player.jump();
  }
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.size = 50;
    this.velocity = 0;
  }

  update() {
    this.velocity += gravity;
    this.y += this.velocity;

    // Impede o jogador de cair para fora da tela
    if (this.y > height - this.size) {
      this.y = height - this.size;
      this.velocity = 0;
    }
  }

  jump() {
    if (this.y === height - this.size) {
      this.velocity = -8; // Força do pulo
    }
  }

  show() {
    fill(0, 150, 255);
    rect(this.x, this.y, this.size, this.size);
  }
}

class Obstacle {
  constructor() {
    this.x = random(width);
    this.y = -20;
    this.size = random(30, 50);
    this.speed = random(3, 6);
  }

  update() {
    this.y += this.speed;
  }

  show() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.size, this.size);
  }

  offscreen() {
    return this.y > height;
  }

  hits(player) {
    if (
      player.x < this.x + this.size &&
      player.x + player.size > this.x &&
      player.y < this.y + this.size &&
      player.y + player.size > this.y
    ) {
      return true;
    }
    return false;
  }
}